const ethers = require('ethers')
const term = require( 'terminal-kit' ).terminal ;

let wallet;
let seed;
function delay(time) {
    return new Promise(resolve => setTimeout(resolve, time));
  } 

  function terminate() {
	term.grabInput( false ) ;
	setTimeout( function() { process.exit() } , 100 ) ;
}
const header = ()=>{
    term.moveTo(1,1)
    term.clear()
    term.bold.cyan( 'Type anything on the keyboard...\n' ) ;
    term.green( 'Hit CTRL-C to quit.\n\n' ) ;
    term.green( 'Hit n to create new wallet.\n\n' ) ;
    term.green( 'Hit s to show address of wallet.\n\n' ) ;
    term.green( 'Hit number 1-9,0(10),-(11),=(12) to show seed of wallet.\n\n' ) ;
    term.green( 'Hit F to show all seed of wallet.\n\n' ) ;
    
}
header()
term.grabInput( { mouse: 'button' } ) ;

term.on( 'key' , function( name , matches , data ) {
    header()
	if(name=='n'){
        wallet = ethers.Wallet.createRandom();
        seed = wallet.mnemonic.phrase.split(" ")
        term.green('address:'+ wallet.address ) ;
    }
	if(name=='s'){
        term.green('address:'+ wallet.address ) ;
    }
    if(name=='0'){
        term.green(seed[9]) ;
    }
    if(name=='1'){
        term.green(seed[0]) ;
    }
    if(name=='2'){
        term.green(seed[1]) ;
    }
    if(name=='3'){
        term.green(seed[2]) ;
    }
    if(name=='4'){
        term.green(seed[3]) ;
    }
    if(name=='5'){
        term.green(seed[4]) ;
    }
    if(name=='6'){
        term.green(seed[5]) ;
    }
    if(name=='7'){
        term.green(seed[6]) ;
    }
    if(name=='8'){
        term.green(seed[7]) ;
    }
    if(name=='9'){
        term.green(seed[8]) ;
    }
    if(name=='-'){
        term.green(seed[10]) ;
    }
    if(name=='='){
        term.green(seed[11]) ;
    }
    if(name=='f'){
        term.green(wallet.mnemonic.phrase) ;
    }
	if ( name === 'CTRL_C' ) { terminate() ; }
} ) ;

term.on( 'terminal' , function( name , data ) {
	console.log( "'terminal' event:" , name , data ) ;
} ) ;

term.on( 'mouse' , function( name , data ) {
	console.log( "'mouse' event:" , name , data ) ;
} ) ;

async function run() {
    
    term( 'Hello world!\n' ) ;
    term.on( 'key' , function( name , matches , data ) {
        console.log( "'key' event:" , name ) ;
        if ( name === 'CTRL_C' ) { terminate() ; }
    } ) ;
    let randomWallet = ethers.Wallet.createRandom();
    const wallet = Wallet.fromMnemonic('one two three four ...', `m/44'/60'/0'/0/1`);
    console.log(JSON.stringify(randomWallet, null, 2))

}


