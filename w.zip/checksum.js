const ethers = require('ethers')

var main = function(){
    
    const address = process.argv[2]
    try {
        const _address = ethers.getAddress(address)
        console.log('valid address');
      } catch(e) { 
        console.error('================= invalid ethereum address ==============')
      }

}

main();